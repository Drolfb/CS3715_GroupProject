# CS3715_GroupProject
A drawing game where players compete to see who has the best drawing skills. 
